const SubTitulos = ({tit}) =>{
    return(
        <h2 className="h3 pl-4 py-2 b-radios bg-azul-escuro branco font-weight-semibold">{tit}</h2>
    );
};
export default SubTitulos;