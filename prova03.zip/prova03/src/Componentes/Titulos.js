const Titulos = (props) => {    
    return( 
        <h1 className="azul-claro h2">{props.tit}</h1>
    );
};
export default Titulos;
